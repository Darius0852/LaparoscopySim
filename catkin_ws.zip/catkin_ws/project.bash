source ~/catkin_ws/devel/setup.bash

export PYTHONPATH=${PYTHONPATH}:/home/user/catkin_ws/src/python_modules