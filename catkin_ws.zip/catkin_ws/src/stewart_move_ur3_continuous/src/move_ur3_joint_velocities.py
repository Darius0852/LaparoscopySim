#! /usr/bin/env python

#Author: Stewart Craig

import sys
import copy
import rospy
import select, termios, tty
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import math

from std_msgs.msg import String
from moveit_commander.conversions import pose_to_list
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from joint_velocities import *

settings = termios.tcgetattr(sys.stdin)

msg = """
--------------------------------------

--------------------------------------
up,   down:  	w   s
left, right:    a   d
in,   out	r   e
--------------------------------------

--------------------------------------
Robot Information
--------------------------------------
RPY Angles:  v
Robot State: i
--------------------------------------
Quit
--------------------------------------
q
"""

def getKey():
	tty.setraw(sys.stdin.fileno())
    	select.select([sys.stdin], [], [], 0)
	key = sys.stdin.read(1)
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
	return key

def moveUR3(move_group, constraint, movement):
	jointVelocities = constraint.getNewVelocities()
	sendJointVelocities()

class MoveUR3:

	up = 0
	down = 1
	left = 2
	right = 3
	inward = 4
	outward = 5

	moveit_commander.roscpp_initialize(sys.argv)
	rospy.init_node('move_group_python_interface_tutorial', anonymous=True)
	robot = moveit_commander.RobotCommander()
	scene = moveit_commander.PlanningSceneInterface()
	move_group = moveit_commander.MoveGroupCommander("manipulator")
	display_trajectory_publisher = rospy.Publisher('/move_group/display_planned_path', moveit_msgs.msg.DisplayTrajectory, queue_size=1)
	move_group.set_planning_time(5)
	move_group.set_named_target('home')
	move_group.go(wait=True)
	print msg

	initialJoints = [-0.4059791607070613, -1.002263895870593, 1.9871999972734162, 2.1556085349855856, -1.1642390316934232, -7.241302432792196e-05]

	move_group.set_joint_value_target(initialJoints)

	plan = move_group.plan()
	
	move_group.go(wait=True)

	wpose = move_group.get_current_pose().pose
	constraint = Constraint(wpose, wpose)

	while(1):
		key = getKey()

		if(getKey() == "w"):
			positions = constraint.getPositions(wpose, up)

			while(getKey() == "w"):
				moveUR3(move_group, constraint, up)

		if(getKey() == "s"):
			positions = constraint.getPositions(wpose, down)

			while(getKey() == "s"):
				moveUR3(move_group, constraint, down)

		if(getKey() == "a"):
			positions = constraint.getPositions(wpose, left)

			while(getKey() == "a"):
				moveUR3(move_group, constraint, left)

		if(getKey() == "d"):
			positions = constraint.getPositions(wpose, right)

			while(getKey() == "d"):
				moveUR3(move_group, constraint, right)

		if(getKey() == "r"):
			positions = constraint.getPositions(wpose, inward)

			while(getKey() == "r"):
				moveUR3(move_group, constraint, inward)
			
		if(getKey() == "e"):
			positions = constraint.getPositions(wpose, outward)

			while(getKey() == "e"):
				moveUR3(move_group, constraint, outward)

		if(key == "v"):
			orientation_q = move_group.get_current_pose().pose.orientation
			orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
    			(roll, pitch, yaw) = euler_from_quaternion (orientation_list)
			print roll
			print pitch
			print yaw

		if(key == "i"):
			print ""
			print "Reference frame: %s" % move_group.get_planning_frame()
			print ""
			print "End effector: %s" % move_group.get_end_effector_link()
			print ""
			print "Robot Groups:"
			print robot.get_group_names()
			print ""
			print "Current Joint Values:"
			print move_group.get_current_joint_values()
			print ""
			print "Current Pose:"
			print move_group.get_current_pose()
			print ""
			print "Robot State:"
			print robot.get_current_state()
			print ""
			
		if(key == "q"):
			move_group.set_named_target('home')
			move_group.go(wait=True)
			break

	move_group.stop()
	moveit_commander.roscpp_shutdown()
	termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)


if __name__ == "__main__":
	MoveUR3()
