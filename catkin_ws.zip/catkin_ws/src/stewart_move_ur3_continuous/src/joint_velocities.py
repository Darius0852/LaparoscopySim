#! /usr/bin/env python

# Author: Stewart Craig

import sys
import rospy
import geometry_msgs.msg
import math
from tf.transformations import euler_from_quaternion, quaternion_from_euler


class Constraint:

	def __init__(self, centrePose, pose):

		self.a = centrePose.position.x
		self.b = (centrePose.position.y + 0.25)
		self.c = (centrePose.position.z - 0.25)

		self.X = pose.position.x
		self.Y = pose.position.y
		self.Z = pose.position.z

		self.radius = self.calculateRadius()
		self.longitude = self.calculateLongitude()
		self.latitude = self.calculateLatitude()
		self.longitudeOriginal = self.calculateLongitude()
		self.latitudeOriginal = self.calculateLatitude()

		self.latitudeMaximum = round(math.degrees(self.latitude)) + 25
		self.latitudeMinimum = round(math.degrees(self.latitude)) - 25
		self.longitudeMaximum = round(math.degrees(self.longitude)) + 25
		self.longitudeMinimum = round(math.degrees(self.longitude)) - 25
		self.angleIncrement = math.radians(1)

		self.positions = []

	def calculateRadius(self):
		squareRoot =  ((self.X - self.a) * (self.X - self.a))
		squareRoot += ((self.Y - self.b) * (self.Y - self.b))
		squareRoot += ((self.Z - self.c) * (self.Z - self.c))

		return math.sqrt(squareRoot)


	def calculateLongitude(self):

		value = math.atan2((self.b - self.Y), (self.a - self.X))

		return value
		
	
	def calculateLatitude(self):

		value = math.atan2((self.b - self.Y), ((self.c - self.Z) * math.sin(self.longitude)))

		return value

	def getPositions(self, pose, movement):

		validMovement = 0
		latitude = round(math.degrees(self.latitude))
		longitude = round(math.degrees(self.longitude))

		if movement == 0:
			validMovement = 1
			for x in range(0, int(round(self.latitudeMaximum) - latitude)):
				self.positions.append(self.getNewPose(pose, self.radius, latitude + x, self.longitude))

		if movement == 1:
			validMovement = 1
			for x in range(int(latitude), int(round(self.latitudeMinimum))):
				print self.latitude + x
				self.positions.append(self.getNewPose(pose, self.radius, self.latitude + x, self.longitude))

		if movement == 2:
			validMovement = 1
			for x in range(int(latitude), int(round(self.latitudeMaximum))):
				print self.latitude + x
				self.positions.append(self.getNewPose(pose, self.radius, self.latitude + x, self.longitude))

		if movement == 3:
			validMovement = 1
			for x in range(int(latitude), int(round(self.latitudeMaximum))):
				print self.latitude + x
				self.positions.append(self.getNewPose(pose, self.radius, self.latitude + x, self.longitude))

		if movement == 4:
			validMovement = 1
			for x in range(int(latitude), int(round(self.latitudeMaximum))):
				print self.latitude + x
				self.positions.append(self.getNewPose(pose, self.radius, self.latitude + x, self.longitude))

		if movement == 5:
			validMovement = 1
			for x in range(int(latitude), int(round(self.latitudeMaximum))):
				print self.latitude + x
				self.positions.append(self.getNewPose(pose, self.radius, self.latitude + x, self.longitude))

		if validMovement == 0:
			print "Can't go there!"
			return joint_velocities


		return self.positions

	def getNewVelocities(self, pose, movement):

		joint_velocities = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
		return joint_velocities

	def getNewPose(self, pose, radius, latitude, longitude):

		X = (self.a - (radius * math.cos(longitude) * math.sin(latitude)))
		Y = (self.b - (radius * math.sin(longitude) * math.sin(latitude)))
		Z = (self.c - (radius * math.cos(latitude)))

		pose.position.x = X 
		pose.position.y = Y 
		pose.position.z = Z
		pose.orientation = self.getOrientation(pose, latitude, longitude)

		return pose

	def getOrientation(self, pose, latitude, longitude):
		
		quatern = pose.orientation
		quatern_list = [quatern.x, quatern.y, quatern.z, quatern.w]
		(roll, pitch, yaw) = euler_from_quaternion(quatern_list)
		
		roll = -(latitude - self.latitudeOriginal)
		pitch = math.radians(round(math.degrees(pitch)))
		yaw = longitude - self.longitudeOriginal


		quat = quaternion_from_euler(roll, pitch, yaw)

		pose.orientation.x = quat[0]
		pose.orientation.y = quat[1]
		pose.orientation.z = quat[2]
		pose.orientation.w = quat[3]
		
		return pose.orientation
	
	def getLatitude(self):
		return self.latitude

	def getLongitude(self):
		return self.longitude

	def getLatitudeMaximum(self):
		return self.latitudeMaximum

	def getLatitudeMinimum(self):
		return self.latitudeMinimum

	def getLongitudeMaximum(self):
		return self.latitudeMaximum

	def getLongitudeMinimum(self):
		return self.longitudeMinimum

