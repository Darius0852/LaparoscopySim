#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
using namespace std;
//Server side
int MasterCon(int a){
    return 0;
}
int SlaveCon(int a){
    return 0;
}
int main(int argc, char *argv[])
{    
    int port = 11110;


    //buffer to send and receive messages with
    char ready[10];
    string data = "ready";
    strcpy(ready, data.c_str());
    char msg[1500];
    char msg2[1500];
    sockaddr_in servAddr;
    int serverSd;
    int bindStatus;
     
    //setup a socket and connection tools
    if (argc!=2){
        while(1){
            bzero((char*)&servAddr, sizeof(servAddr));
            servAddr.sin_family = AF_INET;
            servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
            servAddr.sin_port = htons(port);
 
            serverSd = socket(AF_INET, SOCK_STREAM, 0);
            bindStatus = bind(serverSd, (struct sockaddr*) &servAddr, sizeof(servAddr));
            //open stream oriented socket with internet address
            //also keep track of the socket descriptor
            if((serverSd < 0 || bindStatus < 0) && port<11120)
            {
                cout << "Error establishing the server socket" <<port << endl;
                port++;
                //exit(0);
            }
            //bind the socket to its local address
            /*int bindStatus = bind(serverSd, (struct sockaddr*) &servAddr, 
                sizeof(servAddr));
            if(bindStatus < 0)
            {
                cerr << "Error binding socket to local address" << endl;
                //exit(0);
            }*/
            if (port>11119){
                //cout << "Error establishing the server socket" <<port << endl;
                cout<<"Port Error, Please check the firewall setting"<<endl;
                exit(0);
            }
            if (serverSd >= 0 && bindStatus >= 0){
                cout<<"Server started on port "<<port<<endl;
                break;
            }
        
        }
    }

    if (argc == 2){
        port = atoi(argv[1]);
        bzero((char*)&servAddr, sizeof(servAddr));
        servAddr.sin_family = AF_INET;
        servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
        servAddr.sin_port = htons(port);
 
        serverSd = socket(AF_INET, SOCK_STREAM, 0);
        bindStatus = bind(serverSd, (struct sockaddr*) &servAddr, sizeof(servAddr));

        if(serverSd < 0 || bindStatus < 0)
        {
            cout << "Error establishing the server socket" <<port << endl;
            exit(0);
        }
        if (serverSd >= 0 && bindStatus >= 0)
            cout<<"Server started on port "<<port<<endl;

    }


    cout << "Waiting for a client to connect..." << endl;
    //listen for up to 5 requests at a time
    listen(serverSd, 5);
    //receive a request from client using accept
    //we need a new address to connect with the client
    sockaddr_in newSockAddr;
    socklen_t newSockAddrSize = sizeof(newSockAddr);
    sockaddr_in newSockAddr2;
    socklen_t newSockAddrSize2 = sizeof(newSockAddr2);
    //accept, create a new socket descriptor to 
    //handle the new connection with client
    int newSd = accept(serverSd, (sockaddr *)&newSockAddr, &newSockAddrSize);
    if(newSd < 0)
    {
        cerr << "Error accepting request from client!" << endl;
        exit(1);
    }
    int newSd2 = accept(serverSd, (sockaddr *)&newSockAddr2, &newSockAddrSize2);
    if(newSd < 0)
    {
        cerr << "Error accepting request from client!" << endl;
        exit(1);
    }
    cout << "Connected with client 1!" << newSockAddr.sin_port<< endl;
    cout << "Connected with client 2!" << newSockAddr2.sin_port<< endl;
    memset(&msg, 0, sizeof(msg));//clear the buffer
    memset(&msg2, 0, sizeof(msg2));//clear the buffer
    recv(newSd, (char*)&msg, sizeof(msg), 0);
    recv(newSd2, (char*)&msg2, sizeof(msg), 0);
    if(!strcmp(msg, msg2)){
        cout<<"Cannot accept two masters or two slaves."<<endl;
        exit(0);
    }
    //tell clients that serve is ready
    send(newSd, (char*)&ready, strlen(ready), 0);
    send(newSd2, (char*)&ready, strlen(ready), 0);

    while(1){  
        if(!strcmp(msg2, "m") || !strcmp(msg, "s"))//slave side connects to server faster than master side 
        {
            cout << "Client 1 is slave side" << endl;
            cout << "Client 2 is master side" << endl;
            struct timeval start1, end1;
            gettimeofday(&start1, NULL);
            //also keep track of the amount of data sent as well
            int bytesRead, bytesRecv = 0;
            while(1)
            {
                //receive a message from the client (listen)
                //cout << "Awaiting client response..." << endl;
                memset(&msg, 0, sizeof(msg));//clear the buffer
                memset(&msg2, 0, sizeof(msg2));//clear the buffer
               
                //bytesRead += recv(newSd, (char*)&msg, sizeof(msg), 0);
                bytesRead = recv(newSd2, (char*)&msg2, sizeof(msg2), 0); //if nothing is received, master is lost
                if (bytesRead>0)
                    send(newSd, (char*)&msg2, strlen(msg2), 0);
                else {
                    cout << "Master lost" << endl;
                    memset(&msg, 0, sizeof(msg));
                    string data2="99";
                    strcpy(msg2, data2.c_str());
                    send(newSd, (char*)&msg2, strlen(msg2), 0);
                    newSd2 = 0; //set it to 0 for reconnection
                    memset(&msg, 0, sizeof(msg));
                    memset(&msg2, 0, sizeof(msg2));//clear the buffer
                    break;
                }

                if(!strcmp(msg2, "~"))
                {
                    cout << "Master has quit the session" << endl;
                    break;
                }
                bytesRecv = recv(newSd, (char*)&msg, sizeof(msg), 0); //make sure salve side is here
                if (bytesRecv<=0){
                    cout << "Slave lost" <<msg<<msg2<<endl;
                    newSd = 0; //set it to 0 for reconnection
                    send(newSd2, (char*)&msg2, strlen(msg2), 0);
                    memset(&msg, 0, sizeof(msg));
                    memset(&msg2, 0, sizeof(msg2));//clear the buffer
                    break;
                }        
                else
                    send(newSd2, (char*)&ready, strlen(ready), 0);    
            }
        }
        if(!strcmp(msg, "m") || !strcmp(msg2, "s"))//master side connects to server faster than slave side
        {
            cout << "Client 1 is master side" << endl;
            cout << "Client 2 is slave side" << endl;
            struct timeval start1, end1;
            gettimeofday(&start1, NULL);
            //also keep track of the amount of data sent as well
            int bytesRead, bytesRecv = 0;
            while(1)
            {
                //receive a message from the client (listen)
                //cout << "Awaiting client response..." << endl;
                memset(&msg, 0, sizeof(msg));//clear the buffer
                memset(&msg2, 0, sizeof(msg2));//clear the buffer
                //bytesRead += recv(newSd, (char*)&msg, sizeof(msg), 0);
                bytesRead = recv(newSd, (char*)&msg2, sizeof(msg2), 0);
                if (bytesRead>0)
                    send(newSd2, (char*)&msg2, strlen(msg2), 0);
                else {
                    cout << "lost" << endl;
                    memset(&msg2, 0, sizeof(msg));
                    string data2="99";
                    strcpy(msg2, data2.c_str());
                    send(newSd2, (char*)&msg2, strlen(msg2), 0);
                    newSd = 0;
                    memset(&msg, 0, sizeof(msg));
                    memset(&msg2, 0, sizeof(msg2));//clear the buffer
                    break;
                }
                if(!strcmp(msg2, "~"))
                {
                    cout << "Master has quit the session" << endl;
                    break;
                }
                bytesRecv = recv(newSd2, (char*)&msg, sizeof(msg), 0); //make sure salve side is here
                if (bytesRecv<=0){
                    cout << "Slave lost" << endl;
                    newSd2 = 0; //set it to 0 for reconnection
                    send(newSd, (char*)&msg2, strlen(msg2), 0);
                    memset(&msg, 0, sizeof(msg));
                    memset(&msg2, 0, sizeof(msg2));//clear the buffer
                    break;
                }
                else
                    send(newSd, (char*)&ready, strlen(ready), 0);  
            }
        }

    
        if (newSd == 0 || newSd2 == 0 ){
            cout << "Waiting to reconnect." << endl;
            if (newSd == 0){
                listen(serverSd, 5);
                newSd = accept(serverSd, (sockaddr *)&newSockAddr2, &newSockAddrSize2);
                recv(newSd, (char*)&msg, sizeof(msg2), 0);
                if(!strcmp(msg, "s")){
                    //sleep(200000);
                    send(newSd2, (char*)&ready, sizeof(ready), 0);                   
                }
                //usleep(200000);
                send(newSd, (char*)&ready, sizeof(ready), 0);
                    cout << "Master is back" << endl;

            }
            if (newSd2 == 0){
                listen(serverSd, 5);
                newSd2 = accept(serverSd, (sockaddr *)&newSockAddr2, &newSockAddrSize2);
                recv(newSd2, (char*)&msg2, sizeof(msg2), 0);
                if(!strcmp(msg2, "s")){
                    //usleep(200000);
                    send(newSd, (char*)&ready, sizeof(ready), 0);
                }
                //usleep(200000);
                send(newSd2, (char*)&ready, sizeof(ready), 0);
                    cout << "Master is back" << newSd2<< endl;

            }

        }
        if (newSd != 0 && newSd2 != 0 && !strcmp(msg2, "~")){
        close(newSd);
        close(newSd2);
        close(serverSd);
        break;
        }
    }

    return 0;   
}