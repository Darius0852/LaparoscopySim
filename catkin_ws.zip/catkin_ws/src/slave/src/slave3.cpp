#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>


using namespace std;
//Slave side
int main(int argc, char *argv[])
{
    string IP = "127.0.0.1";
    char serverIp[16];
    strcpy(serverIp, IP.c_str());
    int port = 11110; 

    //create a message buffer 
    char msg[1500]; 

    struct hostent* host; 
    sockaddr_in sendSockAddr;   
    int clientSd;

    //setup a socket and connection tools 
    if(argc != 3){
        while(1){
            hostent* host = gethostbyname(serverIp);   
            bzero((char*)&sendSockAddr, sizeof(sendSockAddr)); 
            sendSockAddr.sin_family = AF_INET; 
            sendSockAddr.sin_addr.s_addr = 
                inet_addr(inet_ntoa(*(struct in_addr*)*host->h_addr_list));
            sendSockAddr.sin_port = htons(port);
            clientSd = socket(AF_INET, SOCK_STREAM, 0);

        //try to connect...
            int status = connect(clientSd,
                                (sockaddr*) &sendSockAddr, sizeof(sendSockAddr));
            if(status < 0 && port<11120)
            {
                cout<<"Server is not running on port " << port<<endl;
                port++; 
            }
            if(port>11119){
                //cout<<"Server is not running on port " << port<<endl;
                cout<<"Server is not running"<<endl;
                cout<<"Please check the server program and the firewall setting"<<endl;
                exit(0);
            }
            if (!(status<0)){
                cout<<port<<endl;
                break;
            }
        }
    }

    if (argc == 3){
        IP = argv[1];
        strcpy(serverIp, IP.c_str()); 
        port = atoi(argv[2]);   
        hostent* host = gethostbyname(serverIp);   
        bzero((char*)&sendSockAddr, sizeof(sendSockAddr)); 
        sendSockAddr.sin_family = AF_INET; 
        sendSockAddr.sin_addr.s_addr = 
            inet_addr(inet_ntoa(*(struct in_addr*)*host->h_addr_list));
        sendSockAddr.sin_port = htons(port);
        clientSd = socket(AF_INET, SOCK_STREAM, 0);    
        int status = connect(clientSd,
                            (sockaddr*) &sendSockAddr, sizeof(sendSockAddr)); 
        if (!(status<0))
            cout<<port<<endl;
        else{
            cout<<"Server is not running on "<<IP<<" & port " << port <<endl;
            exit(0);
        }
    }

    cout << "Connected to the server!" << endl;
    int bytesRead, bytesWritten = 0;
    struct timeval start1, end1;
    gettimeofday(&start1, NULL);
    
    string data;
    data = "s";
    //getline(cin, data);
    memset(&msg, 0, sizeof(msg));//clear the buffer
    strcpy(msg, data.c_str());
    bytesWritten += send(clientSd, (char*)&msg, strlen(msg), 0);
    memset(&msg, 0, sizeof(msg));
    cout<<"waiting master"<<endl;
    recv(clientSd, (char*)&msg, sizeof(msg), 0);

    ros::init(argc, argv, "slave");
    ros::NodeHandle n;
    ros::Publisher slavePub = n.advertise<std_msgs::String>("slaveCommand", 1);
    ros::Rate loop_rate(100);


    if(!strcmp(msg, "ready")){





    while (ros::ok())
    {   bytesRead = 0;
	std_msgs::String msg2;
   
        std::stringstream ss;


        //cout << "Awaiting server response..." << endl;
        memset(&msg, 0, sizeof(msg));//clear the buffer
        bytesRead = recv(clientSd, (char*)&msg, sizeof(msg), 0);
        if(!strcmp(msg, "~"))
        {
            cout << "Server and master have quit the session" << endl;
            break;
        }
        if(bytesRead>0){
             ss << msg;
             msg2.data = ss.str();
             ROS_INFO("%s", msg2.data.c_str());
             slavePub.publish(msg2);
             send(clientSd, (char*)&msg, strlen(msg), 0); //tell server you are still connected
        }
        else{
            cout<<"Server is closed, please ensure server is opened."<<endl;
            break;
        }

     loop_rate.sleep();
   

    }
}

    gettimeofday(&end1, NULL);
    close(clientSd);

    return 0;    
}
