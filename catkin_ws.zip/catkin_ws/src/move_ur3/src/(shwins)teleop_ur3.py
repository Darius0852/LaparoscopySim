#!/usr/bin/env python

'''
Code for MEng4 Group Project: Training System for Robotic Laparoscopy

Authors:

Ashwin Rajendran - Setting Initial Pose, Keyboard Input, Robot State Info, Sending data to Serial Port, Publishers/Subscribers, Argument Parsing, Jog_arm and MoveIt!

Stewart Craig    - Connection to constrained movement code, moving back to home position in a controlled manner, setting robot positions and hole positions

Zhepin Choong    - Wiimote, Nunchuk and Xbox Controls (Xbox to be added)

'''

import rospy
import moveit_commander
import moveit_msgs.msg
import pygame
from geometry_msgs.msg import TwistStamped, Pose
from move_ur3.msg import JogJoint
from sensor_msgs.msg import Joy
from moveit_ros_planning_interface._moveit_move_group_interface import MoveGroupInterface
from constraint_continuous_refactored import *
from robot2 import *
import argparse
import sys, select, termios, tty
import serial
import time

keycontrols = """
Controlling the UR3
---------------------------

Keyboard Controls:			
up, down	= w, s
left, right	= a, d
in, out		= e, q

quit		= space
"""

wiicontrols = """
Controlling the UR3
---------------------------

Wiimote Controls:			
up, down	= up, down
left, right	= left, right
in, out		= b, a

Nunchuk to be added

CTRL-C to quit
"""

xboxcontrols = """
"""

global buttonOrMotion
global startPosition
global firstPress
global startPositionNunchuk
global firstPressNunchuk
global rightArmPose
global robot1_pub
global robot1_move_group
global robot1_constraint
global robot1_pose_original
global debugMode
global arduinoSerial
global arduino

def currentJoint(move_group):
	return move_group.get_current_joint_values()

def publishJointMovement(sp,sl,e,w1,w2,w3,publisher):
	joint = JogJoint()
        joint.joint_names = ["shoulder_pan_joint","shoulder_lift_joint","elbow_joint","wrist_1_joint","wrist_2_joint","wrist_3_joint"]
        joint.deltas = [sp,sl,e,w1,w2,w3]
	print "im going here"
	print joint
	publisher.publish(joint)

def moveToStart(move_group,joint_publisher):

	joint1 = -0.0931
	joint2 = -1.1470
	joint3 = 1.6766
	joint4 = -3.6275
	joint5 = -1.4468
	joint6 = -3.1763

	currentJointValues = currentJoint(move_group)

	joint = JogJoint()
        joint.joint_names = ["shoulder_pan_joint","shoulder_lift_joint","elbow_joint","wrist_1_joint","wrist_2_joint","wrist_3_joint"]
        joint.deltas = [1,0,0,0,0,0]
	joint_publisher.publish(joint)
	time.sleep(3)
	joint.deltas = [0,0,0,0,0,0]
	joint_publisher.publish(joint)


#moving robots back to starting pose in a controlled manner
def moveToHome(move_group, constraint, publisher, robot1or2):
	pose = getCurrentPose(robot1or2, move_group)

	while round(constraint.getToolDisplacementOriginal(), 3) < round(constraint.getToolDisplacement(), 3):
		pose = getCurrentPose(robot1or2, move_group)
		moveRobot(move_group, constraint, 4, publisher, robot1or2)

	while round(constraint.getToolDisplacementOriginal(), 3) > round(constraint.getToolDisplacement(), 3):
		pose = getCurrentPose(robot1or2, move_group)
		moveRobot(move_group, constraint, 5, publisher, robot1or2)

	while round(constraint.getLatitudeOriginal(), 1) > round(constraint.getLatitude(), 1):
		moveRobot(move_group, constraint, 0, publisher, robot1or2)

	while round(constraint.getLatitudeOriginal(), 1) < round(constraint.getLatitude(), 1):
		moveRobot(move_group, constraint, 1, publisher, robot1or2)

	while round(constraint.getLongitudeOriginal(), 1) < round(constraint.getLongitude(), 1):
		moveRobot(move_group, constraint, 2, publisher, robot1or2)

	while round(constraint.getLongitudeOriginal(), 1) > round(constraint.getLongitude(), 1):
		moveRobot(move_group, constraint, 3, publisher, robot1or2)
	

#calculate the linear and angular velocites and publish to jog_arm 
def moveRobot(move_group, constraint, movement, publisher, robot1or2):
	
	global debugMode

	linear_x = 0
	linear_y = 0
	linear_z = 0
	angular_x = 0
	angular_y = 0
	angular_z = 0

	if movement == 8:
		moveToHome(move_group, constraint, publisher, robot1or2)

		print("Robot {0}: Ready to move".format(robot1or2))

		if robot1or2 == 2:
			print("Both robots ready to move!".format(robot1or2))
			

	if (movement >= 0 and movement <= 7):
		pose = getCurrentPose(robot1or2, move_group)

		velocities = constraint.calculateVelocities(pose, movement, robot1or2, debugMode)

		if(velocities[0] != 'e'):
			linear_x = velocities[0]
			linear_y = velocities[1]
			linear_z = velocities[2]
			angular_x = velocities[3]
			angular_y = velocities[4]
			angular_z = velocities[5]

	twist = TwistStamped()
	twist.twist.linear.x = linear_x
	twist.twist.linear.y = linear_y
	twist.twist.linear.z = linear_z
	twist.twist.angular.x = angular_x
	twist.twist.angular.y = angular_y
	twist.twist.angular.z = angular_z

	twist.header.stamp = rospy.Time.now()
	
	publisher.publish(twist)


#controlling the robot via keyboard
def keyboardControls(robot1_move_group, robot1_constraint, robot1_pub, joint_publisher):
	global debugMode
	global arduinoSerial
	global arduino
	global rate

	while(1):

		#using pygame so we can detect multiple keypresses simultaneously
		pygame.event.pump()
		keys = pygame.key.get_pressed()

		if(keys[pygame.K_ESCAPE]):
			#arduinoSerial.close()
			sys.exit()

		robot1_movement = -1

		if(keys[pygame.K_g]):
			while(keys[pygame.K_g]):
				pygame.event.pump()
				keys = pygame.key.get_pressed()

			debugMode = (debugMode + 1) % 2

			if debugMode == 1:
				print "Debug Mode: Enabled"
			else:
				print "Debug Mode: Disabled"

		if(keys[pygame.K_s]):
			robot1_movement = 0 #up
		elif(keys[pygame.K_w]):
			robot1_movement = 1 #down
		elif(keys[pygame.K_d]):
			robot1_movement = 2 #left
		elif(keys[pygame.K_a]):
			robot1_movement = 3 #right
		elif(keys[pygame.K_e]):
			robot1_movement = 4 #in
		elif(keys[pygame.K_q]):
			robot1_movement = 5 #out
		elif(keys[pygame.K_p]):
			moveToStart(robot1_move_group,joint_publisher)
                elif keys[pygame.K_r]:
			while(keys[pygame.K_r]):
				pygame.event.pump()
				keys = pygame.key.get_pressed()
			if(arduino == 1):
				arduinoSerial.write('l\n') #open/close left surgical tool
				arduinoSerial.flush()
			else:
				print "arduino not connected" 
		elif keys[pygame.K_z]:
			while(keys[pygame.K_z]):
				pygame.event.pump()
				keys = pygame.key.get_pressed()
			if(arduino == 1):
				arduinoSerial.write('c\n') #rotate
				arduinoSerial.flush()
			else:
				print "arduino not connected"
		elif keys[pygame.K_x]:
			while(keys[pygame.K_x]):
				pygame.event.pump()
				keys = pygame.key.get_pressed()
			if(arduino == 1):
				arduinoSerial.write('v\n') #rotate
				arduinoSerial.flush()  

		if(keys[pygame.K_SPACE]):

			robot1_movement = 8 

		if(keys[pygame.K_1]):
			print "Robot 1 Pose"
			print getCurrentPose(1, robot1_move_group)

			pose = getCurrentPose(1, robot1_move_group)
    			orientation_list = [pose.orientation.x,pose.orientation.y,pose.orientation.z,pose.orientation.w]
    			(roll, pitch, yaw) = euler_from_quaternion (orientation_list)
    			print "Roll " + str(roll) + ", Pitch " + str(pitch) + ", Yaw "  + str(yaw)

		moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)

		rate.sleep()

	

#controlling the robot on the right with wiimote
def callbackWii(msg):
	global buttonOrMotion
	global startPosition
	global firstPress
	global arduinoSerial
	global arduino
        global rate

	movement = -1

	if(msg.buttons[10] == 1):
			print "Both robots moving home"
			movement = 8

	#select motion or button controls on wiimote
	if(msg.buttons[0] == 1):
		buttonOrMotion = 0
	
	if(msg.buttons[1] == 1):
		buttonOrMotion = 1	

	if(buttonOrMotion == 0):
		messageValue = msg.buttons[4] + msg.buttons[5] + msg.buttons[6] + msg.buttons[7] + msg.buttons[8] + msg.buttons[9] + msg.buttons[3] + msg.buttons[2]

		if(messageValue == 1):
			if(msg.buttons[8] == 1):
				movement = 0  #up
			if(msg.buttons[9] == 1):
				movement = 1  #down
			if(msg.buttons[4] == 1):
				movement = 4  #in
			if(msg.buttons[5] == 1):
				movement = 5  #out
			if(msg.buttons[6] == 1 and msg.buttons[3] == 0):
				movement = 2  #left
			if(msg.buttons[7] == 1 and msg.buttons[3] == 0):
				movement = 3  #right
			if(msg.buttons[2] == 1):
				if(arduino == 1):
					arduinoSerial.write('r\n') #open/close right surgical tool
					arduinoSerial.flush()
				else:
					print "arduino not connected"   
			if(msg.buttons[3] == 1 and msg.buttons[6] == 1):
				if(arduino == 1):
					arduinoSerial.write('c\n') #open/close right surgical tool
					arduinoSerial.flush()
				else:
					print "arduino not connected"
			if(msg.buttons[3] == 1 and msg.buttons[7] == 1):
				if(arduino == 1):
					arduinoSerial.write('v\n') #open/close right surgical tool
					arduinoSerial.flush()
				else:
					print "arduino not connected"
 
	
	if(buttonOrMotion == 1):
		if(msg.buttons[3] == 1):
			if(arduino == 1):
				arduinoSerial.write('r\n') #open/close right surgical tool
				arduinoSerial.flush()
			else:
				print "arduino not connected"   
		if(msg.buttons[2] == 0):
			firstPress = 1
		if(msg.buttons[8] == 1):
			movement = 4 #in
		elif(msg.buttons[9] == 1):
			movement = 5 #out
		elif(msg.buttons[2] == 1):
			if(firstPress == 1):
				firstPress = 0
				#calibrating position that will be used as centre point for wiimote motion controls
				startPosition = [msg.axes[0], msg.axes[1]]
				
			if(msg.axes[0] - startPosition[0] < -2):
				movement = 2 #left
			elif(msg.axes[0] - startPosition[0] > 2):
				movement = 3 #right
			elif(msg.axes[1] - startPosition[1] < -2):
				movement = 1 #down
			elif(msg.axes[1] - startPosition[1] > 2):
				movement = 0 #up

	moveRobot(robot1_move_group, robot1_constraint, movement, robot1_pub, 1)

	rate.sleep()


#get current pose of the robot using move_group interface
#robot 2's pose is published by robot2.py
def getCurrentPose(robot, robot_move_group):
	if robot == 1:
		pose_array = robot_move_group.get_current_pose("ee_link")
		pose = Pose()
		pose.position.x = pose_array.pose.position.x
		pose.position.y = pose_array.pose.position.y
		pose.position.z = pose_array.pose.position.z
		pose.orientation.x = pose_array.pose.orientation.x
		pose.orientation.y = pose_array.pose.orientation.y
		pose.orientation.z = pose_array.pose.orientation.z
		pose.orientation.w = pose_array.pose.orientation.w
		return pose

#get commands to move robot via the internet
def decodeCommand(data):
	global arduinoSerial
	global arduino

	code = data.data
	print ("code = {0}".format(code))

	robot1_movement = -1

	global arduinoSerial

	if(code[0] == '8' or code[1] == '8'):
		print "Both robots moving home"
		robot1_movement = 8

	if(code[0] == '0'):
		robot1_movement = 0 #up
	elif(code[0] == '1'):
		robot1_movement = 1 #down
	elif(code[0] == '2'):
		robot1_movement = 2 #left
	elif(code[0] == '3'):
		robot1_movement = 3 #right
	elif(code[0] == '4'):
		robot1_movement = 4 #in
	elif(code[0] == '5'):
		robot1_movement = 5 #out
	elif(code[0] == '6'):
		if(arduino == 1):
			arduinoSerial.write('l\n') #open/close left surgical tool
			arduinoSerial.flush()
		else:
			print "arduino not connected"  

	moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)

	

if __name__=="__main__":
	global arduino
	# parsing command line arguments to get teleoperation modes
        parser = argparse.ArgumentParser()
	parser.add_argument("-k", "--keyboard", help="control via keyboard input", action="store_true")
        parser.add_argument("-w", "--wii", help="control via wiimote and nunchuk", action="store_true")
        parser.add_argument("-i", "--ip", help="get input via ip", action="store_true")
	parser.add_argument("-x", "--xbox", help="get input via xbox", action="store_true")
	parser.add_argument("-r", "--arduino", help="set arduino com port", required=True)
	args = parser.parse_known_args()

	global debugMode
	debugMode = 0

	rospy.init_node('teleop_ur3')
	global robot1_pub
	global joint_publisher

	robot1_pub = rospy.Publisher('jog_arm_server/delta_jog_cmds', TwistStamped, queue_size=5)
	joint_publisher = rospy.Publisher('jog_arm_server/joint_delta_jog_cmds', JogJoint, queue_size=5)
	rospy.Subscriber("slaveCommand", String, decodeCommand,  queue_size=1)

	global robot1_move_group
	print "Robot 1: Initialising MoveGroup..."
	robot1_move_group = moveit_commander.MoveGroupCommander("manipulator")
	print "Robot 1: MoveGroup initialised"

	global buttonOrMotion
	buttonOrMotion = 0

	global startPosition
	startPosition = [0, 0]
	global firstPress
	firstPress = 1

	global startPositionNunchuk
	startPositionNunchuk = [0, 0]
	global firstPressNunchuk
	firstPressNunchuk = 1

	robot1_pose = getCurrentPose(1, robot1_move_group)

	

	
	# get pose after robots have moved into position
	while round((robot1_pose.position.x + robot1_pose.position.y + robot1_pose.position.z), 3) == 0:
		print robot1_pose
		robot1_pose = getCurrentPose(1, robot1_move_group)


	robot1_xyz = [robot1_pose.position.x, robot1_pose.position.y, robot1_pose.position.z]
	
	print("Robot 1: Pose set to x = {0} y = {1} z = {2}".format(robot1_xyz[0], robot1_xyz[1], robot1_xyz[2]))

	hole1Position = [0.6115, 0.2375, 0.234]
	#hole1Position[0] += 0.238
	print("Robot 1: Hole position set to x = {0} y = {1} z = {2}".format(hole1Position[0], hole1Position[1], hole1Position[2]))

	global robot1_constraint

	print "Robot 1: Initialising constraint..."
	robot1_constraint = Constraint(hole1Position, robot1_pose, 1)
	print "Robot 1: Constraint initialised"
	
	global robot1_pose_original

	robot1_pose_original = robot1_pose

	print args[0]

	
	arduino = 0

	global rate

        rate = rospy.Rate(125) 

	# depending on command line arguments, start the corresponding teleoperation modes
	if args[0].ip:
    		rospy.Subscriber("slaveCommand", String, decodeCommand)
		print "Ready and awaiting remote commands..."  

	if args[0].wii:
    		rospy.Subscriber("joy", Joy, callbackWii)
		print wiicontrols 

	if args[0].xbox:
    		rospy.Subscriber("joy", Joy, callbackXbox)
		print xboxcontrols  

	if (args[0].arduino != '0'):
    		global arduinoSerial
		global arduino
		arduino = 1
		arduinoSerial = serial.Serial(args[0].arduino, 9600)
		arduinoSerial.isOpen() 

	if args[0].keyboard:
                pygame.init()
	        pygame.display.set_mode((200, 200))
    		keyboardControls(robot1_move_group, robot1_constraint, robot1_pub, joint_publisher)
                print keycontrols

	rospy.spin()


