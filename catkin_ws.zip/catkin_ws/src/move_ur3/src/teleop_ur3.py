#!/usr/bin/env python

'''
Code for MEng4 Group Project: Training System for Robotic Laparoscopy

Authors:

Ashwin Rajendran - Setting Initial Pose, Keyboard Input, Robot State Info, Sending data to Serial Port, Publishers/Subscribers, Argument Parsing, Jog_arm and MoveIt!

Stewart Craig    - Connection to constrained movement code, moving back to home position in a controlled manner, setting robot positions and hole positions

Zhepin Choong    - Wiimote, Nunchuk and Xbox Controls (Xbox to be added)

Darius Ghomashchian - Added controls to command the gripper in the simulation. 

'''

import rospy
import moveit_commander
import moveit_msgs.msg
import pygame
from geometry_msgs.msg import TwistStamped, Pose
from move_ur3.msg import JogJoint
from sensor_msgs.msg import Joy
from moveit_ros_planning_interface._moveit_move_group_interface import MoveGroupInterface
from constraint_continuous_refactored import *
from robot2 import *
import argparse
import sys, select, termios, tty
import serial
import time
from trajectory_msgs.msg import JointTrajectory
from trajectory_msgs.msg import JointTrajectoryPoint
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Time
from std_msgs.msg import Header
from std_msgs.msg import Duration
import time

keycontrols = """
Controlling the UR3
---------------------------

Keyboard Controls:			
up, down	= w, s
left, right	= a, d
in, out		= e, q

quit		= space
"""

wiicontrols = """
Controlling the UR3
---------------------------

Wiimote Controls:			
up, down	= up, down
left, right	= left, right
in, out		= b, a

Nunchuk to be added

CTRL-C to quit
"""

xboxcontrols = """
"""

global buttonOrMotion
global startPosition
global firstPress
global startPositionNunchuk
global firstPressNunchuk
global rightArmPose
global robot1_pub
global robot2_pub
global robot1_move_group
global robot2_move_group
global robot1_constraint
global robot2_constraint
global robot1_pose_original
global robot2_pose_original
global debugMode
global arduinoSerial
global arduino
global timeList
global robot1_move_group2
global robot2_move_group2

#using MoveIt! to set the starting pose of the robot
def moveToPosition(move_group):
	print "Robot 1: Moving to start position..."

	joints = [-0.4077300962905772, -1.000450504976346, 1.9879762960761926, 2.1525135932534774, -1.1629908975489993, -0.6733131188]
	move_group.set_joint_value_target(joints)
	plan = move_group.compute_plan()
	move_group.execute(plan)
	move_group.stop()

	print "Robot 1: Arrived at start position"
	
def moveToPositionRight(move_group):
	print "Robot 2: Moving to start position..."

	joints = [2.70014205105716, -1.0004447883711522, 1.9881939472018466, 2.15498283887933, -1.1241401572239287, 3.814905772]
	move_group.set_joint_value_target(joints)
	plan = move_group.compute_plan()
	move_group.execute(plan)
	move_group.stop()

	print "Robot 2: Arrived at start position"

#moving robots back to starting pose in a controlled manner
def moveToHome(move_group, constraint, publisher, robot1or2):
	pose = getCurrentPose(robot1or2, move_group)

	while round(constraint.getToolDisplacementOriginal(), 3) < round(constraint.getToolDisplacement(), 3):
		pose = getCurrentPose(robot1or2, move_group)
		moveRobot(move_group, constraint, 4, publisher, robot1or2)

	while round(constraint.getToolDisplacementOriginal(), 3) > round(constraint.getToolDisplacement(), 3):
		pose = getCurrentPose(robot1or2, move_group)
		moveRobot(move_group, constraint, 5, publisher, robot1or2)

	while round(constraint.getLatitudeOriginal(), 1) > round(constraint.getLatitude(), 1):
		moveRobot(move_group, constraint, 0, publisher, robot1or2)

	while round(constraint.getLatitudeOriginal(), 1) < round(constraint.getLatitude(), 1):
		moveRobot(move_group, constraint, 1, publisher, robot1or2)

	while round(constraint.getLongitudeOriginal(), 1) < round(constraint.getLongitude(), 1):
		moveRobot(move_group, constraint, 2, publisher, robot1or2)

	while round(constraint.getLongitudeOriginal(), 1) > round(constraint.getLongitude(), 1):
		moveRobot(move_group, constraint, 3, publisher, robot1or2)
	

#calculate the linear and angular velocites and publish to jog_arm 
def moveRobot(move_group, constraint, movement, publisher, robot1or2):
	
	start = time.time()

	global debugMode
	global timeList 

	linear_x = 0
	linear_y = 0
	linear_z = 0
	angular_x = 0
	angular_y = 0
	angular_z = 0



    #Movement 11,12,13,14 are for robot1 gripper

	if movement == 11:
		print("GRIPPER CLOSING")

        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot1/robot_description", "robot1")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot1/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [0,current_joint[0]-0.2,current_joint[0]+0.2]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)


	if movement == 12:
		print("GRIPPER OPENING")

        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot1/robot_description", "robot1")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot1/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [0,current_joint[0]+0.2,current_joint[0]-0.2]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)

    if movement == 13:

        print("GRIPPERS TURNING LEFT")

        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot1/robot_description", "robot1")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot1/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [current_joint[0]-1,0,0,]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)


	if movement == 14:
		print("GRIPPERS TURNING RIGHT")


        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot1/robot_description", "robot1")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot1/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [current_joint[0]+1,0,0,]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)


    #Movement 15,16,17,18 are for robot2 gripper

	if movement == 15:
		print("GRIPPER CLOSING")

        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot2/robot_description", "robot2")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot2/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [0,current_joint[0]-0.2,current_joint[0]+0.2]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)


	if movement == 16:
		print("GRIPPER OPENING")

        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot2/robot_description", "robot2")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot2/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [0,current_joint[0]+0.2,current_joint[0]-0.2]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)

    if movement == 17:

        print("GRIPPERS TURNING LEFT")

        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot2/robot_description", "robot2")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot2/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [current_joint[0]-1,0,0,]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)


	if movement == 18:
		print("GRIPPERS TURNING RIGHT")


        #Get current joint positions of gripper using MoveIt! and save values
        moveit_group = MoveGroupInterface("Gripper", "robot2/robot_description", "robot2")
        group = moveit_commander.MoveGroupCommander(moveit_group)
        current_joints = group.get_current_joint_values()


        #Use rospub to change to new position
        pub = rospy.Publisher('/robot2/gripper_controller/command', JointTrajectory, queue_size=10)

        joints_str = JointTrajectory()
        joints_str.header = Header()
        joints_str.header.stamp = rospy.Time.now()
        joints_str.joint_names = ['swivel_joint', 'left_gripper_joint', 'right_gripper_joint']
        point=JointTrajectoryPoint()
        point.positions = [current_joint[0]+1,0,0,]
        point.time_from_start = rospy.Duration(1)
        joints_str.points.append(point)

        pub.publish(joints_str)
        time.sleep(0.5)

	if movement == 8:
		moveToHome(move_group, constraint, publisher, robot1or2)

		print("Robot {0}: Ready to move".format(robot1or2))

		if robot1or2 == 2:
			print("Both robots ready to move!".format(robot1or2))
			

	if (movement >= 0 and movement <= 5):
		pose = getCurrentPose(robot1or2, move_group)

		velocities = constraint.calculateVelocities(pose, movement, robot1or2, debugMode)

		if(velocities[0] != 'e'):
			linear_x = velocities[0]
			linear_y = velocities[1]
			linear_z = velocities[2]
			angular_x = velocities[3]
			angular_y = velocities[4]
			angular_z = velocities[5]

	twist = TwistStamped()
	twist.twist.linear.x = linear_x
	twist.twist.linear.y = linear_y
	twist.twist.linear.z = linear_z
	twist.twist.angular.x = angular_x
	twist.twist.angular.y = angular_y
	twist.twist.angular.z = angular_z

	twist.header.stamp = rospy.Time.now()
	
	end = time. time()
	
	timeList.append(end - start)

	if movement == 10:

		maximum = max(timeList)
		minimum = min(timeList)
		average = sum(timeList) / len(timeList)

		print("Max = {0}s Slowest Frequency = {3}Hz Min = {1}s Fastest Frequency = {4}Hz Average = {2}s Average Frequency = {5}Hz".format(round(maximum, 6), round(minimum, 6), round(average, 6), round(1/maximum, 1), round(1/minimum, 1), round(1/average, 1)))

	publisher.publish(twist)

#controlling the robot via keyboard
def keyboardControls(robot1_move_group, robot2_move_group, robot1_constraint, robot2_constraint, robot1_pub, robot2_pub):
	global debugMode
	global arduinoSerial
	global arduino

	while(1):

		#using pygame so we can detect multiple keypresses simultaneously
		pygame.event.pump()
		keys = pygame.key.get_pressed()

		if(keys[pygame.K_ESCAPE]):
			arduinoSerial.close()
			sys.exit()

		robot1_movement = -1
		robot2_movement = -1

		if(keys[pygame.K_g]):
			while(keys[pygame.K_g] == 1):
				pygame.event.pump()
				keys = pygame.key.get_pressed()

			debugMode = (debugMode + 1) % 2

			if debugMode == 1:
				print "Debug Mode: Enabled"
			else:
				print "Debug Mode: Disabled"

		if(keys[pygame.K_w]):
			robot1_movement = 0 #up
		elif(keys[pygame.K_v]):
			robot1_movement = 11 #close gripper
		elif(keys[pygame.K_c]):
			robot1_movement = 12 #open gripper
		elif(keys[pygame.K_r]):
			robot1_movement = 13 #close gripper
		elif(keys[pygame.K_f]):
			robot1_movement = 14 #open gripper
		elif(keys[pygame.K_s]):
			robot1_movement = 1 #down
		elif(keys[pygame.K_a]):
			robot1_movement = 2 #left
		elif(keys[pygame.K_d]):
			robot1_movement = 3 #right
		elif(keys[pygame.K_e]):
			robot1_movement = 4 #in
		elif(keys[pygame.K_q]):
			robot1_movement = 5 #out
		elif(keys[pygame.K_z]):
			robot1_movement = 6
			#print "Left anti-clockwise"
		elif(keys[pygame.K_x]):
			robot1_movement = 7
			#print "Left clockwise"
                elif keys[pygame.K_y]:
			if(arduino == 1):
				while(keys[pygame.K_y] == 1):
					pygame.event.pump()
					keys = pygame.key.get_pressed()
					
				arduinoSerial.write('r\n') #open/close left surgical tool
				arduinoSerial.flush()
			else:
				print "arduino not connected"  
 
		if(keys[pygame.K_i]):
			robot2_movement = 0 #up
		elif(keys[pygame.K_k]):
		elif(keys[pygame.K_n]):
			robot2_movement = 15 #close gripper
		elif(keys[pygame.K_b]):
			robot2_movement = 16 #open gripper
		elif(keys[pygame.K_y]):
			robot2_movement = 17 #turn gripper right
		elif(keys[pygame.K_h]):
			robot2_movement = 18 #turn gripper left
		elif(keys[pygame.K_j]):
			robot2_movement = 2 #left
		elif(keys[pygame.K_l]):
			robot2_movement = 3 #right
		elif(keys[pygame.K_u]):
			robot2_movement = 4 #in 
		elif(keys[pygame.K_o]):
			robot2_movement = 5 #out
		elif(keys[pygame.K_n]):
			robot2_movement = 6
			#print "Right anti-clockwise"
		elif(keys[pygame.K_m]):
			robot2_movement = 7
			#print "Right clockwise"
		elif keys[pygame.K_r]:
			if(arduino == 1):
				while(keys[pygame.K_r] == 1):
					pygame.event.pump()
					keys = pygame.key.get_pressed()
					
				arduinoSerial.write('l\n') #open/close right surgical tool
				arduinoSerial.flush()
			else:
				print "arduino not connected"  

		if(keys[pygame.K_SPACE]):
			robot2_movement = 8 #home
			robot1_movement = 8 
		if(keys[pygame.K_1]):
			print "Robot 1 Pose"
			print getCurrentPose(1, robot1_move_group)

			pose = getCurrentPose(1, robot1_move_group)
    			orientation_list = [pose.orientation.x,pose.orientation.y,pose.orientation.z,pose.orientation.w]
    			(roll, pitch, yaw) = euler_from_quaternion (orientation_list)
    			print "Roll " + str(roll) + ", Pitch " + str(pitch) + ", Yaw "  + str(yaw)

			print "Robot 2 Pose"
			print getCurrentPose(2, robot2_move_group)
				
			pose = getCurrentPose(2, robot2_move_group)
    			orientation_list = [pose.orientation.x,pose.orientation.y,pose.orientation.z,pose.orientation.w]
    			(roll, pitch, yaw) = euler_from_quaternion (orientation_list)
    			print "Roll " + str(roll) + ",Pitch " + str(pitch) + ",Yaw "  + str(yaw)
			

		if(keys[pygame.K_p]):
			i = 0
			while(i < 100000):
				print i
				robot1_movement = i % 6
				moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)
				i += 1
			robot1_movement = 10
			moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)
			

		moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)
		moveRobot(robot2_move_group, robot2_constraint, robot2_movement, robot2_pub, 2)

#controlling the robot on the right with wiimote
def callbackWii(msg):
	global buttonOrMotion
	global startPosition
	global firstPress
	global robot2_move_group
	global robot2_constraint
	global robot2_pub
	global arduinoSerial
	global arduino

	movement = -1

	if(msg.buttons[10] == 1):
			print "Both robots moving home"
			movement = 8

	#select motion or button controls on wiimote
	if(msg.buttons[0] == 1):
		buttonOrMotion = 0
	
	if(msg.buttons[1] == 1):
		buttonOrMotion = 1	

	if(buttonOrMotion == 0):
		messageValue = msg.buttons[4] + msg.buttons[5] + msg.buttons[6] + msg.buttons[7] + msg.buttons[8] + msg.buttons[9]

		if(messageValue == 1):
			if(msg.buttons[8] == 1):
				movement = 0  #up
			if(msg.buttons[9] == 1):
				movement = 1  #down
			if(msg.buttons[6] == 1):
				movement = 2  #left
			if(msg.buttons[7] == 1):
				movement = 3  #right
			if(msg.buttons[4] == 1):
				movement = 4  #in
			if(msg.buttons[5] == 1):
				movement = 5  #out
			if(msg.buttons[3] == 1):
				if(arduino == 1):
					arduinoSerial.write('r\n') #open/close right surgical tool
					arduinoSerial.flush()
				else:
					print "arduino not connected"   
	
	if(buttonOrMotion == 1):
		if(msg.buttons[3] == 1):
			if(arduino == 1):
				arduinoSerial.write('r\n') #open/close right surgical tool
				arduinoSerial.flush()
			else:
				print "arduino not connected"   
		if(msg.buttons[2] == 0):
			firstPress = 1
		if(msg.buttons[8] == 1):
			movement = 4 #in
		elif(msg.buttons[9] == 1):
			movement = 5 #out
		elif(msg.buttons[2] == 1):
			if(firstPress == 1):
				firstPress = 0
				#calibrating position that will be used as centre point for wiimote motion controls
				startPosition = [msg.axes[0], msg.axes[1]]
				
			if(msg.axes[0] - startPosition[0] < -2):
				movement = 2 #left
			elif(msg.axes[0] - startPosition[0] > 2):
				movement = 3 #right
			elif(msg.axes[1] - startPosition[1] < -2):
				movement = 1 #down
			elif(msg.axes[1] - startPosition[1] > 2):
				movement = 0 #up

	moveRobot(robot2_move_group, robot2_constraint, movement, robot2_pub, 2)

#controlling the robot on the left with nunchuk
def callbackNunchuk(msg):
	global startPositionNunchuk
	global firstPressNunchuk
	global robot1_move_group
	global robot1_constraint
	global robot1_pub
        global arduinoSerial
	global arduino

	movement = -1

	if(msg.buttons[0] == 1):
		if(arduino == 1):
			arduinoSerial.write('l\n') #open/close left surgical tool
			arduinoSerial.flush()
		else:
			print "arduino not connected"   
	if(msg.buttons[1] == 0):
		firstPressNunchuk = 1
	if(msg.axes[1] > 0.75):
		movement = 4 #in
	elif(msg.axes[1] < -0.75):
		movement = 5 #out
	elif(msg.buttons[1] == 1):
		if(firstPressNunchuk == 1):
			firstPressNunchuk = 0
			#calibrating position that will be used as centre point for nunchuk motion controls
			startPositionNunchuk = [msg.axes[0], msg.axes[1]]
			
		if(msg.axes[2] - startPositionNunchuk[0] < -2):
			movement = 2 #left
		elif(msg.axes[2] - startPositionNunchuk[0] > 2):
			movement = 3 #right
		elif(msg.axes[3] - startPositionNunchuk[1] < -2):
			movement = 1 #down
		elif(msg.axes[3] - startPositionNunchuk[1] > 2):
			movement = 0 #up

	moveRobot(robot1_move_group, robot1_constraint, movement, robot1_pub, 1)
	

#controlling the robot on the left with xbox (in prpgress) 
def callbackXbox(msg):

	global robot2_move_group
	global robot2_constraint
	global robot2_pub

	global robot1_move_group
	global robot1_constraint
	global robot1_pub

	global arduinoSerial
	global arduino

	robot1_movement = -1
	robot2_movement = -1

	moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)
	moveRobot(robot2_move_group, robot2_constraint, robot2_movement, robot2_pub, 2)


#get current pose of the robot using move_group interface
#robot 2's pose is published by robot2.py
def getCurrentPose(robot, robot_move_group):
	if robot == 1:
		pose_array = robot_move_group.get_current_pose("ee_link")
		pose = Pose()
		pose.position.x = pose_array[0]
		pose.position.y = pose_array[1]
		pose.position.z = pose_array[2]
		pose.orientation.x = pose_array[3]
		pose.orientation.y = pose_array[4]
		pose.orientation.z = pose_array[5]
		pose.orientation.w = pose_array[6]
		return pose
	if robot == 2:
		global rightArmPose
		return rightArmPose

#get commands to move robot via the internet
def decodeCommand(data):
	global arduinoSerial
	global arduino

	code = data.data
	print ("code = {0}".format(code))

	robot1_movement = -1
	robot2_movement = -1

	global arduinoSerial

	if(code[0] == '8' or code[1] == '8'):
		print "Both robots moving home"
		robot1_movement = 8
		robot2_movement = 8

	if(code[0] == '0'):
		robot1_movement = 0 #up
	elif(code[0] == '1'):
		robot1_movement = 1 #down
	elif(code[0] == '2'):
		robot1_movement = 2 #left
	elif(code[0] == '3'):
		robot1_movement = 3 #right
	elif(code[0] == '4'):
		robot1_movement = 4 #in
	elif(code[0] == '5'):
		robot1_movement = 5 #out
	elif(code[0] == '6'):
		if(arduino == 1):
			arduinoSerial.write('l\n') #open/close left surgical tool
			arduinoSerial.flush()
		else:
			print "arduino not connected"  

	if(code[1] == '0'):
		robot2_movement = 0 #up
	elif(code[1] == '1'):
		robot2_movement = 1 #down
	elif(code[1] == '2'):
		robot2_movement = 2 #left
	elif(code[1] == '3'):
		robot2_movement = 3 #right
	elif(code[1] == '4'):
		robot2_movement = 4 #in
	elif(code[1] == '5'):
		robot2_movement = 5 #out
	elif(code[1] == '6'):
		if(arduino == 1):
			arduinoSerial.write('r\n') #open/close right surgical tool
			arduinoSerial.flush()
		else:
			print "arduino not connected"  


	moveRobot(robot1_move_group, robot1_constraint, robot1_movement, robot1_pub, 1)
	moveRobot(robot2_move_group, robot2_constraint, robot2_movement, robot2_pub, 2)


#rightArmPose subscriber calls this function to update robot2's pose
def savePose(msg):
	global rightArmPose
	rightArmPose = msg


if __name__=="__main__":
	global timeList 
	timeList = []

	# parsing command line arguments to get teleoperation modes
        parser = argparse.ArgumentParser()
	parser.add_argument("-k", "--keyboard", help="control via keyboard input", action="store_true")
        parser.add_argument("-w", "--wii", help="control via wiimote and nunchuk", action="store_true")
        parser.add_argument("-i", "--ip", help="get input via ip", action="store_true")
	parser.add_argument("-x", "--xbox", help="get input via xbox", action="store_true")
	parser.add_argument("-r", "--arduino", help="set arduino com port")
	args = parser.parse_known_args()

	global debugMode
	debugMode = 0

	rospy.init_node('teleop_ur3')
	global robot1_pub
	global robot2_pub

	robot1_pub = rospy.Publisher('robot1/jog_arm_server/delta_jog_cmds', TwistStamped, queue_size=1)
	robot2_pub = rospy.Publisher('robot2/jog_arm_server/delta_jog_cmds', TwistStamped, queue_size=1)
	rospy.Subscriber("rightArmPose", Pose, savePose)
	rospy.Subscriber("slaveCommand", String, decodeCommand,  queue_size=1)

	global robot1_move_group
	global robot2_move_group

	print "Robot 1: Initialising MoveGroup..."
	robot1_move_group = MoveGroupInterface("manipulator", "robot1/robot_description", "robot1")
	print "Robot 1: MoveGroup initialised"

	print "Robot 2: Initialising MoveGroup..."
	robot2_move_group = MoveGroupInterface("manipulator", "robot2/robot_description", "robot2")
	print "Robot 2: MoveGroup initialised"

	global rightArmPose

	rightArmPose = Pose()

	moveToPosition(robot1_move_group)
	moveToPositionRight(robot2_move_group)

	global buttonOrMotion
	buttonOrMotion = 0

	global startPosition
	startPosition = [0, 0]
	global firstPress
	firstPress = 1

	global startPositionNunchuk
	startPositionNunchuk = [0, 0]
	global firstPressNunchuk
	firstPressNunchuk = 1

	robot1_pose = getCurrentPose(1, robot1_move_group)
	robot2_pose = getCurrentPose(2, robot2_move_group)

	
	# get pose after robots have moved into position
	while round((robot1_pose.position.x + robot1_pose.position.y + robot1_pose.position.z), 3) == 0:
		robot1_pose = getCurrentPose(1, robot1_move_group)

	while round((robot2_pose.position.x + robot2_pose.position.y + robot2_pose.position.z), 3) == 0:
		robot2_pose = getCurrentPose(2, robot2_move_group)

	robot1_xyz = [robot1_pose.position.x, robot1_pose.position.y, robot1_pose.position.z]
	robot2_xyz = [robot2_pose.position.x, robot2_pose.position.y, robot2_pose.position.z]
	
	print("Robot 1: Pose set to x = {0} y = {1} z = {2}".format(robot1_xyz[0], robot1_xyz[1], robot1_xyz[2]))
	print("Robot 2: Pose set to x = {0} y = {1} z = {2}".format(robot2_xyz[0], robot2_xyz[1], robot2_xyz[2]))

	hole1Position = [0.35502, 0.18, 0.13]
	hole1Position[0] += 0.238
	print("Robot 1: Hole position set to x = {0} y = {1} z = {2}".format(hole1Position[0], hole1Position[1], hole1Position[2]))

	hole2Position = [-0.35575, 0.18, 0.13]
	hole2Position[0] -= 0.238
	print("Robot 2: Hole position set to x = {0} y = {1} z = {2}".format(hole2Position[0], hole2Position[1], hole2Position[2]))

	global robot1_constraint
	global robot2_constraint

	print "Robot 1: Initialising constraint..."
	robot1_constraint = Constraint(hole1Position, robot1_pose, 1)
	print "Robot 1: Constraint initialised"

	print "Robot 2: Initialising constraint..."
	robot2_constraint = Constraint(hole2Position, robot2_pose, 2)
	print "Robot 2: Constraint initialised"
	
	global robot1_pose_original
	global robot2_pose_original

	robot1_pose_original = robot1_pose
	robot2_pose_original = robot2_pose

	print args[0]

	global arduino
	arduino = 0

	# depending on command line arguments, start the corresponding teleoperation modes
	if args[0].ip:
    		rospy.Subscriber("slaveCommand", String, decodeCommand)
		print "Ready and awaiting remote commands..."  

	if args[0].wii:
    		rospy.Subscriber("joy", Joy, callbackWii)
		rospy.Subscriber("wiimote/nunchuk", Joy, callbackNunchuk)
		print wiicontrols 

	if args[0].xbox:
    		rospy.Subscriber("joy", Joy, callbackXbox)
		print xboxcontrols  

	if (args[0].arduino != '0'):
    		global arduinoSerial
		global arduino
		arduino = 1
		arduinoSerial = serial.Serial(args[0].arduino, 9600)
		arduinoSerial.isOpen() 

	if args[0].keyboard:
                pygame.init()
	        pygame.display.set_mode((200, 200))
    		keyboardControls(robot1_move_group, robot2_move_group, robot1_constraint, robot2_constraint, robot1_pub, robot2_pub)
                print keycontrols

	rospy.spin()


