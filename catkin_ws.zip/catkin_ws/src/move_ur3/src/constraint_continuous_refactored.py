#! /usr/bin/env python

# Author: Stewart Craig

import sys
import rospy
import geometry_msgs.msg
import math
from tf.transformations import euler_from_quaternion, quaternion_from_euler


# Class defines a coordinate as having X, Y and Z positions
# ---------------------------------------------------------
class Coordinate:
	def __init__(self, x = 0.0, y = 0.0, z = 0.0):
		self.x = x
		self.y = y
		self.z = z

# Class defines a Vector as having I, J and K components
# ------------------------------------------------------
class Vector:
	def __init__(self, i, j, k):
		self.i = i
		self.j = j
		self.k = k

# Class used to determine the codes accuracy (error percentage)
# -------------------------------------------------------------
# An 'Error' occurs when the angle of latitude or longitude of the tool
# to the centre hole is greater than the calculated tolerance.
# This class keeps track of the number of valid movements made by the
# robot and the number of 'invalid' moves which result in only an
# orientation correction of the robot.
class Error:
	def __init__(self):
		self.validMove = 0.0
		self.invalidMove = 0.0

	def printErrorPercentage(self):
		if(self.validMove == 0.0 and self.invalidMove == 0.0):
			print "Error percentage = 0.000%"
		else:
			percent = 100 * ((self.invalidMove) / (self.validMove + self.invalidMove))
			percent = round(percent, 3)
			print("Error percentage = {0}%".format(percent))

	def incrementValidMove(self):
		self.validMove += 1.0

	def incrementInvalidMove(self):
		self.invalidMove += 1.0

# Class used to calculate the necessary linear and angular velocities
# that constrain the tools movement around the centre hole
# -------------------------------------------------------------------
class Constraint:
	def __init__(self, holePosition, pose, robot): 						# Class initialised with the position of the hole and the robot's initial pose 
		self.hole = Coordinate(holePosition[0], holePosition[1], holePosition[2])	# The hole's position is saved as a coordinate

		orientation = pose.orientation							# Orientation received as quaternion 

		quatern_list = [orientation.x, orientation.y, orientation.z, orientation.w]
		(r, p, yaw) = euler_from_quaternion(quatern_list)				# Orientaion converted to Euler angles (radians)

		roll = p
		pitch = r
		#yaw = y
		
		self.rollOriginal = math.degrees(roll)						# Original roll, pitch and yaw values are saved
		self.pitchOriginal = math.degrees(pitch)					# These are later used to return the robots to 'home'
		self.yawOriginal = math.degrees(yaw)

		TCP = Coordinate(pose.position.x, pose.position.y, pose.position.z)		# Saves the robot's initial starting position as a coordinate

		self.longitudeOriginal = self.calculateLongitude(TCP)				# Longitude calculated and saved as original
		self.latitudeOriginal = self.calculateLatitude(TCP)				# Latitude calculated and saved as original
		self.toolDisplacementOriginal = self.calculateRadius(TCP.x, TCP.y, TCP.z)	# The distance from the robot's TCP to the hole (sphere radius) is saved

		self.latitude = self.latitudeOriginal						# Initialises the latitude to this original latitude
		self.longitude = self.longitudeOriginal						# Initialises the longitude to this original longitude
		self.toolDisplacement = self.toolDisplacementOriginal				# Initialises the radius to this original radius

		self.toolTwistOriginal = pitch
		self.toolTwist = self.toolTwistOriginal

		if(robot == 2):
			self.toolTwistOriginal = self.robot2PitchCorrection(pitch)
			self.toolTwist = self.toolTwistOriginal

		self.toolTwistLimit = 45

		self.angleLimit = 10.0								# Maximum angle (degrees) that the latitude and longitude can diverge from its starting place
		self.toolDisplacementLimit = 0.1						# Maximum distance (metres) that the radius can diverge from its starting place

		vector = Vector(TCP.x - self.hole.x, TCP.y - self.hole.y, TCP.z - self.hole.z)	# This vector describes the distance and direction from the hole, the sphere's centre, to the TCP
		initialToolLength = self.calculateVectorLength(vector)				# Initial distance from the hole to the TCP

		holeDiameter = 0.008								# Hole and tool diameters used to calculate the maximum allowed angle tolerance of the latitude and longitude
		toolDiameter = 0.005

		self.angleTolerance = self.calculateAngleTolerance(holeDiameter, toolDiameter, initialToolLength, self.toolDisplacementLimit)

		self.error = Error()								# Initialises an error object

	def calculateVelocities(self, pose, movement, robot, debug):
		if(robot < 1 or robot > 2):							# Checks a valid robot is chosen
			print("Constraint Error: Invalid robot: {0} is not 1 or 2".format(robot))
			return 'e'

		if(movement < 0 or movement > 7):						# Checks a valid movement is chosen
			print("Constraint Error: Invalid movement: {0} is not between 0 and 7".format(movement))
			return 'e'

		x = 0.0										# Declares velocities as 0.0 to begin
		y = 0.0
		z = 0.0
		omega_x = 0.0
		omega_y = 0.0
		omega_z = 0.0

		TCP = Coordinate(pose.position.x, pose.position.y, pose.position.z)		# Stores the robots TCP position as a coordinate
		longitude = self.calculateLongitude(TCP)					# Calculates the robot's current longitude
		latitude = self.calculateLatitude(TCP)						# Calculates the robot's current latitude

		toolTwist = self.calculateToolTwist(pose.orientation)

		if robot == 2:
			toolTwist = self.robot2PitchCorrection(toolTwist)

		vector = Vector(TCP.x - self.hole.x, TCP.y - self.hole.y, TCP.z - self.hole.z)	# This vector describes the distance and direction from the hole, the sphere's centre, to the TCP
		toolDisplacement = self.calculateVectorLength(vector)				# The current distance from the hole to the TCP

		self.latitude = latitude							# Latitude, longitude and tool displacement saved globally to be checked when the robot returns 'home'
		self.longitude = longitude
		self.toolDisplacement = toolDisplacement


		# The following cases ensure the robot's TCP are within the bounds of the set limits
		# For example, if the received command is 'UP' but the latitude is already at the original latitude + the limit then no velocities are returned
		# One case for each possible movement command
		if(movement == 0 and (math.degrees(latitude) >= self.getLatitudeOriginal() + self.angleLimit)):
			print "Constraint Error: Cannot move further up"
			return 'e'
		if(movement == 1 and (math.degrees(latitude) <= self.getLatitudeOriginal() - self.angleLimit)):
			print "Constraint Error: Cannot move further down"
			return 'e'
		if(movement == 2 and (math.degrees(longitude) <= self.getLongitudeOriginal() - self.angleLimit)):
			print "Constraint Error: Cannot move further left"
			return 'e'
		if(movement == 3 and (math.degrees(longitude) >= self.getLongitudeOriginal() + self.angleLimit)):
			print "Constraint Error: Cannot move further right"
			return 'e'
		if(movement == 4 and (toolDisplacement <= self.toolDisplacementOriginal - self.toolDisplacementLimit)):
			print "Constraint Error: Cannot move closer in"
			return 'e'
		if(movement == 5 and (toolDisplacement >= self.toolDisplacementOriginal + self.toolDisplacementLimit)):
			print "Constraint Error: Cannot move further out"
			return 'e'
		if(movement == 6 and (math.degrees(toolTwist) <= self.getToolTwistOriginal() - self.toolTwistLimit)):
			print "Constraint Error: Cannot turn further anti-clockwise"
			return 'e'
		if(movement == 7 and (math.degrees(toolTwist) >= self.getToolTwistOriginal() + self.toolTwistLimit)):
			print "Constraint Error: Cannot turn further clockwise"
			return 'e'

		if(movement >= 0 and movement <= 5):
			nextLatitude = latitude								# The goal coordinate position of the TCP can be described on the sphere by
			nextLongitude = longitude							# its latitude, longitude and radius. Dependant on the movement, only one of
			nextRadius = toolDisplacement							# these will change so current values are stored as the goal position's values

			if(movement == 0):								# An 'UP' command relates to an increase of the latitude
				nextLatitude = latitude + math.radians(1)
			elif(movement == 1):								# A 'DOWN' command relates to a decrease of the latitude
				nextLatitude = latitude - math.radians(1)
			elif(movement == 2):								# A 'LEFT' command relates to a decrease of the longitude
				nextLongitude = longitude - math.radians(1)
			elif(movement == 3):								# A 'RIGHT' command relates to an increase of the longitude
				nextLongitude = longitude + math.radians(1)
			elif(movement == 4):								# An 'IN' command relates to a decrease of the radius
				nextRadius = toolDisplacement - 0.005
			elif(movement == 5):								# An 'OUT' command relates to an increase of the radius
				nextRadius = toolDisplacement + 0.005

			nextCoordinate = self.sphereCoordinates(nextLatitude, nextLongitude, nextRadius, self.hole)		# Calculates the next goal position

			deltaX = nextCoordinate.x - TCP.x						# The vector describing a path to the next position can be created
			deltaY = nextCoordinate.y - TCP.y						# by finding the difference in the X, Y and Z components of the
			deltaZ = nextCoordinate.z - TCP.z						# current and goal coordinates

			deltaVector = Vector(deltaX, deltaY, deltaZ)					# Creates the vector describing this goal movement in X, Y and Z
		
			unitVector = self.findUnitVector(deltaVector)					# As the goal movement vector only describes a small change, the vectors components 
													# are scaled up to the length of a unit vector. That being the vectors length = 1

			x = unitVector.i								# Each component of this unit vector describes the X, Y and Z velocities required
			y = unitVector.j								# for the TCP to travel either around the sphere or closer/further from the centre
			z = unitVector.k

			if(abs(x) > 1.0):								# The jog arm package ignores all velocities if any of these are greater than precisely 1
				x = self.plusOrMinus(x)							# To ensure all velocities are -1 < velocity < 1 these check are put into place
			if(abs(y) > 1.0):								# As a unit vector is used, then only in an extreme case where only one component of the vector is
				y = self.plusOrMinus(y)							# needed would the velocity be marginally greater than one, however this check is put in to avoid this error
			if(abs(z) > 1.0):
				z = self.plusOrMinus(z)

			# Linear X, Y and Z velocities calculated and -1 <= value <= 1 ensured

		quatern_list = [pose.orientation.x, pose.orientation.y, pose.orientation.z, pose.orientation.w]
		(r, p, yaw) = euler_from_quaternion(quatern_list)

		roll = p									# Euler angles are determined from quaternion
		pitch = r
		#yaw = y

		goalPitch = pitch

		if movement == 6:
			goalPitch = pitch + math.radians(1)
		elif movement == 7:
			goalPitch = pitch - math.radians(1)

		goalPitch = pitch

		if robot == 1:									# Calculates the angle between the robot's desired orientaion its actual orientation
			omega_x = (self.rollOriginal - math.degrees(roll)) - (math.degrees(latitude) - self.getLatitudeOriginal()) 
			omega_y = self.getToolTwist() - math.degrees(goalPitch)
			omega_z = (math.degrees(longitude) - self.getLongitudeOriginal()) - (math.degrees(yaw) - self.yawOriginal)

			if((movement == 0 and omega_x > 0.0) or (movement == 1 and omega_x < 0.0)):
				omega_x = 0.0							# Does not change the robot's roll when moving up but orientation change required is for down
												# and vice versa
			if((movement == 2 and omega_z > 0.0) or (movement == 3 and omega_z < 0.0)):
				omega_z = 0.0							# Does not change the robot's yaw when moving left but orientation change required is for right
												# and vice versa

		if robot == 2:									# Calculates the angle between the robot's desired orientaion its actual orientation
			pitch = self.robot2PitchCorrection(pitch)
			goalPitch = self.robot2PitchCorrection(goalPitch)

			omega_x = ((self.rollOriginal - math.degrees(roll)) - (math.degrees(latitude) - self.getLatitudeOriginal()))
			omega_y = self.getToolTwist() - math.degrees(goalPitch)
			omega_z = (math.degrees(longitude) - self.getLongitudeOriginal()) - (math.degrees(yaw) - self.yawOriginal)

			if((movement == 0 and omega_x > 0.0) or (movement == 1 and omega_x < 0.0)):
				omega_x = 0.0							# Does not change the robot's roll when moving up but orientation change required is for down
												# and vice versa

			if((movement == 2 and omega_z > 0.0) or (movement == 3 and omega_z < 0.0)):
				omega_z = 0.0							# Does not change the robot's yaw when moving left but orientation change required is for right
												# and vice versa

		# Increases the corrective behaviour of the RPY as error in angle approaches the limit
		
		deltaPitch = 0
		
		if(movement != 6 and movement != 7):
			deltaPitch = -(self.getToolTwist() - math.degrees(pitch))
			omega_y = deltaPitch
			
			if robot == 2:
				omega_y = -omega_y
		else:
			if movement == 6:
				omega_y = self.angleTolerance
			if movement == 7:
				omega_y = -self.angleTolerance

			self.toolTwist = pitch

		omega_x = omega_x / self.angleTolerance						# Scales the orientation velocities to be out of the angle tolerance
		omega_y = omega_y / self.angleTolerance
		omega_z = omega_z / self.angleTolerance

		check = 0
		if(abs(omega_x) > 1.0):								# As consequence of the previous division, if these values are greater than 1
			omega_x = self.plusOrMinus(omega_x)					# then the angle tolerance has been surpassed and therefore damage may be caused
			check = 1								# if the TCP continues to move in any X, Y or Z manner
		if(abs(omega_y) > 1.0):
			omega_y = self.plusOrMinus(omega_y)					# To ensure this is not the case, should this occur then the check flag is raised
			check = 1
		if(abs(omega_z) > 1.0):
			omega_z = self.plusOrMinus(omega_z)
			check = 1

		if(check == 1):									# The check flag being raised returns only orientation 'corrections' and no linear movements
			self.error.incrementInvalidMove()					# Increments the invalid move variable within the error class
			self.debug(toolDisplacement, latitude, longitude, x, y, z, omega_x, omega_y, omega_z)
			return [x/2, x/2, x/2, omega_x, omega_y, omega_z]
			
		# Angular X, Y and Z velocities calculated and -1 <= value <= 1 ensured

		if debug == 1:									# Debug prints out the different values used by this function and the velocities return by it
			self.debug(toolDisplacement, latitude, longitude, x, y, z, omega_x, omega_y, omega_z)
			self.error.printErrorPercentage()					# Also prints the percentage of error moves made
 
		"""if(movement == 0 or movement == 1):
			x = x / 5
		if(movement == 2 or movement == 3):
			z = z / 5
		if(movement == 6 or movement == 7):
			x = x / 5
			y = y / 5
			z = z / 5"""

		self.error.incrementValidMove()							# Increments the valid move variable within the error class
		velocities = [x, y, z, omega_x, omega_y, omega_z]
		return velocities

	def debug(self, radius, latitude, longitude, x, y, z, omega_x, omega_y, omega_z):	# Prints these variables for the purpose of debugging
		r = round(radius, 4)
		l1 = round(math.degrees(latitude), 3)
		l2 = round(math.degrees(longitude), 3)
		x1 = round(x, 3)
		y1 = round(y, 3)
		z1 = round(z, 3)
		wx1 = round(omega_x, 3)
		wy1 = round(omega_y, 3)
		wz1 = round(omega_z, 3)	

		print ("rad = {0} lat = {1} long = {2} x = {3} y = {4} z = {5} w_x = {6} w_y = {7} w_z = {8}".format(r, l1, l2, x1, y1, z1, wx1, wy1, wz1))

	def plusOrMinus(self, value):								# This function return 1 if the value is positive,
		if(value == 0.0):								# 		       -1 if the value is negative
			return 0.0								# 		       0 if the value is zero
		elif(value < 0.0):
			return -1
		return 1
												# Calculates the maximum angle tolerance for latitude and longitude
	def calculateAngleTolerance(self, holeDiameter, toolDiameter, initialToolLength, toolDisplacementLimit):
		o = math.sqrt(self.square((holeDiameter - toolDiameter)) / 2)			# The distance in metres (typically less than 0.003) that the tool can be displaced in up/down and left/right
		a = initialToolLength + toolDisplacementLimit					# Maximum allowed distance from TCP and hole

		maximumAngleTolerance = math.atan2(o, a)					# Considering trigonometry, calculates the angle of the triangle
		print("Robot Both: Degrees error allowed by robots = {0} degrees".format(math.degrees(maximumAngleTolerance)))
		return math.degrees(maximumAngleTolerance)

	def square(self, val):									# Square of a number used frequently, function created to decrease chance of error
		return val * val

	def sphereCoordinates(self, latitude, longitude, radius, centre):			# Function determines the X, Y and Z coordinates on a sphere
		o1 = (radius * math.sin(latitude))						# Geometry of triangles and trigonometry used to calculate these values
	
		if latitude > 0.0:
			Z = centre.z + o1
		if latitude < 0.0:
			Z = centre.z - o1
			
		h = math.sqrt((self.square(radius) - self.square(o1)))
		a2 = h * math.cos(longitude)

		if abs(math.degrees(longitude)) < 90.0:
			Y = centre.y - a2
		elif abs(math.degrees(longitude)) > 90.0:
			Y = centre.y + a2

		o2 = h * math.sin(longitude)

		X = centre.x + o2
		
		coordinates = Coordinate(X, Y, Z)
		return coordinates
		
	def calculateLatitude(self, TCP):							# Finds the latitude of the TCP with respect to the hole as a sphere's centre point
		o = (TCP.z - self.hole.z)
		a = math.sqrt(self.square((TCP.x - self.hole.x)) + self.square((TCP.y - self.hole.y)))

		value = math.atan2(o, a)
		return value

	def calculateLongitude(self, TCP):							# Finds the longitude of the TCP with respect to the hole as a sphere's centre point
		o = (TCP.x - self.hole.x)
		a = (TCP.y - self.hole.y)

		value = math.atan2(o, a)

		if value > 0.0:
			value = (math.radians(180.0) - value)
		elif value < 0.0:
			value = -(math.radians(180.0) + value)
			
		return value
		
	def calculateRadius(self, x, y, z):							# Finds the radius, aka the distance, of the TCP with respect to the hole as a sphere's centre point
		squareRoot =  self.square((x - self.hole.x))
		squareRoot += self.square((y - self.hole.y))
		squareRoot += self.square((z - self.hole.z))

		return math.sqrt(squareRoot)

	def calculateVectorLength(self, vector):						# Finds the length of a vector
		squareRoot = self.square(vector.i)
		squareRoot += self.square(vector.j)
		squareRoot += self.square(vector.k)

		return math.sqrt(squareRoot)

	def findUnitVector(self, vector):							# Scales a vectors components to have a vector length of 1
		radius = self.calculateVectorLength(vector)

		if radius == 0:
			unitVector = Vector(0.0, 0.0, 0.0)
			return unitVector

		newi = vector.i / radius
		newj = vector.j / radius
		newk = vector.k / radius

		unitVector = Vector(newi, newj, newk)
		checkForError = self.calculateVectorLength(unitVector)

		if(checkForError < 0.999 or checkForError > 1.001):				# Checks vector length is within 1mm of unit vector
			print("Constraint Error: unit vector length not in range 1 +/- 0.001 unit vector = {0}".format(checkForError))
		else:
			return unitVector


	# Getter functions for variables as required
	# ------------------------------------------

	def getLatitude(self):
		return math.degrees(self.latitude)

	def getLongitude(self):
		return math.degrees(self.longitude)

	def getToolDisplacement(self):
		return self.toolDisplacement

	def getLatitudeOriginal(self):
		return math.degrees(self.latitudeOriginal)

	def getLongitudeOriginal(self):
		return math.degrees(self.longitudeOriginal)

	def getToolDisplacementOriginal(self):
		return self.toolDisplacementOriginal

	def getAngleLimit(self):
		return self.angleLimit

	def calculateToolTwist(self, orientation):
		quatern_list = [orientation.x, orientation.y, orientation.z, orientation.w]
		(r, p, yaw) = euler_from_quaternion(quatern_list)				# Orientaion converted to Euler angles (radians)

		roll = p
		pitch = r
		#yaw = y

		return pitch

	def robot2PitchCorrection(self, pitch):
		newPitch = (self.plusOrMinus(pitch) * (180.0 - abs(math.degrees(pitch))))
		return math.radians(newPitch)

	def getToolTwistOriginal(self):
		return math.degrees(self.toolTwistOriginal)

	def getToolTwist(self):
		return math.degrees(self.toolTwist)


