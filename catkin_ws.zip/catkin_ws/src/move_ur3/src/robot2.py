#!/usr/bin/env python

#Author: Ashwin Rajendran ashwin1996@hotmail.co.uk

import rospy
import moveit_msgs.msg
from geometry_msgs.msg import Pose
from moveit_ros_planning_interface._moveit_move_group_interface import MoveGroupInterface

import sys, select, termios, tty


from std_msgs.msg import String

def posePublisher():
    move_group = MoveGroupInterface("manipulator", "robot2/robot_description", "robot2")
    pub = rospy.Publisher('rightArmPose', Pose, queue_size=1)
    rospy.init_node('rightArmPosePublisher')
    rate = rospy.Rate(100000) 
    while not rospy.is_shutdown():
        pose_array = move_group.get_current_pose("ee_link")
        pose = Pose()
        pose.position.x = pose_array[0]
        pose.position.y = pose_array[1]
        pose.position.z = pose_array[2]
        pose.orientation.x = pose_array[3]
        pose.orientation.y = pose_array[4]
        pose.orientation.z = pose_array[5]
        pose.orientation.w = pose_array[6]
        pub.publish(pose)
	#print move_group.get_current_joint_values()
        rate.sleep()

if __name__ == '__main__':
    try:
        posePublisher()
    except rospy.ROSInterruptException:
        pass







