#!/usr/bin/env bash
# generated from catkin/cmake/templates/setup.bash.in

CATKIN_SHELL=bash

# source setup.sh from same directory as this file
_CATKIN_SETUP_DIR=$(builtin cd "`dirname "${BASH_SOURCE[0]}"`" > /dev/null && pwd)
. "$_CATKIN_SETUP_DIR/setup.sh"

#export pygame package to python path:
export PYTHONPATH=${PYTHONPATH}:/home/user/catkin_ws/src/python_modules

cd ~/catkin_ws/src/move_ur3/src
chmod +x robot2.py
chmod +x robot2.pyc
chmod +x constraint_continuous_refactored.py
chmod +x constraint_continuous_refactored.pyc
chmod +x constraint_continuous_refactored_real.py
chmod +x constraint_continuous_refactored_real.pyc

cd ~

sudo pip install pygame